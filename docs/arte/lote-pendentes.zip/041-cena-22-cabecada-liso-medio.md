<!-- pendente 041 · destino: docs/arte/cenas/22-cabecada/liso-medio -->
> **Pendente 041.** Gere a imagem e salve **nesta mesma pasta** como `imagem.jpeg` (ou `.png`). Depois o comando `python3 docs/arte/gerar-pendentes.py --recolher` leva a imagem para `docs/arte/cenas/22-cabecada/liso-medio/`.

# Cena 22 — Cabeçada — corte Liso médio

> **INSTRUCTIONS FOR THE ASSISTANT — READ FIRST**
> Start from a clean slate. Clear and ignore everything from earlier in this conversation and from any previous conversation: earlier prompts, earlier images, earlier styles and earlier corrections. Use only what is written in this file.
> Then generate one image following the section "Prompt" below. The sections in Portuguese are notes for the human reviewer and are not part of the request.

**Usada em:** Lance aéreo, gol de cabeça e bola parada.

**Como gerar:** abra uma conversa nova e gere do zero com o prompt abaixo. Para reforçar o traço, anexe uma cena aprovada do lote 1 (por exemplo `cenas/04-penalti/liso-medio/imagem.jpeg`) e acrescente no fim: `Use the attached image only as a reference for the painting style and for the player's hair. Do not copy its scene.`

**Arquivo da imagem:** salve nesta pasta como `imagem.jpeg`.

## Prompt

```
Create a vertical 4:5 portrait image at the highest resolution available (about 1856 x 2304 pixels).

STYLE
A semi-realistic painted digital illustration for a mobile football career game. Painterly look: soft blended shading, visible brush texture, gentle gradients of light and shadow, and only very thin, subtle linework. Realistic human proportions and anatomy. It must look hand-painted, not like a cartoon, comic, cel-shaded art, flat vector art, anime, a 3D render or a photograph. Avoid thick black outlines.

SETTING
A full football stadium at night, during a corner kick in a tense match. Floodlights shine from above.

MAIN CHARACTER
One young Brazilian football player, seen entirely from behind so his face is not visible. He has brown skin, medium-length straight dark-brown hair, covering the top of his ears and ending at the nape of his neck, and an athletic build.
He is in mid-air, at the highest point of a jump, in the centre of the frame, with his back to the camera, rising above everyone else, his head about to strike a plain white football that is just above and in front of his forehead. His arms are spread out to the sides for lift, and his legs are bent behind him.

CLOTHING
He wears a plain bright magenta short-sleeved football shirt, plain cyan shorts, plain cyan knee-high socks and plain black boots. The cyan shorts and socks are clearly lit and fully visible.

THE BACK OF THE SHIRT
His hair ends at shoulder height at the lowest. From the shoulders down to the waist, the back of the magenta shirt is fully visible to the camera: one smooth, flat, evenly lit magenta surface with nothing printed on it and nothing covering it (no arm, no hand, no strap, no other person, no object). Software will write the player's number there.

OTHER PEOPLE AND OBJECTS
Below him and to the sides, two opponents also jump but are clearly lower than him. Opponents wear plain light-grey shirts, light-grey shorts and light-grey socks. One team-mate in the same magenta-and-cyan kit watches from the side. Beyond them, slightly out of focus, is the goal with a goalkeeper in a plain dark-grey kit on the line. The softly blurred crowd wears neutral light-grey clothes and waves plain light-grey flags with nothing on them.

COLOUR PLAN - follow it exactly, because software will recolour this image afterwards
- Magenta appears in one place only: the shirts of the player and of his team-mates.
- Cyan appears in one place only: the shorts and socks of the player and of his team-mates.
- Boots are plain black.
- Warm yellow or gold appears only on: the floodlight glow.
- Everything else uses navy blue, concrete grey, off-white, pitch green and muted natural tones. No purple, no pink other than the kit described, no neon colours.

COMPOSITION - follow these positions
- Vertical 4:5. The camera is at chest height, a few metres behind him, looking at the goal.
- The main character is horizontally centred and is the largest figure in the image.
- The main character and all the action are in the upper 60% of the image. His whole body is in the air: his boots are no lower than 65% of the way down from the top edge.
- The lower 40% of the image is calm and dark: the grass fading into deep navy shadow down to the bottom edge, with no objects, no people and no detail, because interface panels will be placed over that area.

MUST NOT APPEAR
- No text, letters or numbers anywhere: not on shirts, boards, screens, papers, flags, walls or signs.
- No logos, crests, badges, sponsor or brand marks on kits, boots, balls, flags, boards, bags or walls.
- No badge, emblem or stripes on the clothes of coaches, staff, reporters or anyone else: tracksuits, jackets and polo shirts are completely plain.
- No watermark or signature, and no interface elements, frames or borders.
- The face of the main character is not visible: he is seen from behind.
- Every person is an original fictional character who does not resemble any real person.
```

> **AFTER GENERATING — FINAL STEP**
> Save the generated image to Google Drive, in the same folder where this file is stored, with the file name `imagem.jpeg`. If you cannot save to Drive yourself, say so clearly and show the image so that the user can save it to that folder manually.


## Conferência (nota para revisão humana)

- [ ] Formato vertical 4:5, na resolução maior (1856×2304)
- [ ] Jogador de costas, rosto não aparece, cabelo no corte **Liso médio**
- [ ] Costas da camisa lisas e livres do ombro à cintura, sem nada na frente
- [ ] Magenta só nas camisas; ciano só em calções e meiões; chuteiras pretas
- [ ] Torcida, bandeiras e adversários em cinza; nada além do uniforme em magenta ou ciano
- [ ] Jogador no ar, mais alto que os adversários
- [ ] Braços abertos para os lados, sem cobrir as costas
- [ ] Sem texto, número, escudo, logo ou marca d'água (nem a estrela do Gemini fora da faixa escura)
- [ ] Parte de baixo (40%) escura e vazia
