<!-- pendente 051 · destino: docs/arte/cenas/24-classico/curto -->
> **Pendente 051.** Gere a imagem e salve **nesta mesma pasta** como `imagem.jpeg` (ou `.png`). Depois o comando `python3 docs/arte/gerar-pendentes.py --recolher` leva a imagem para `docs/arte/cenas/24-classico/curto/`.

# Cena 24 — Clássico — corte Curto

> **INSTRUCTIONS FOR THE ASSISTANT — READ FIRST**
> Start from a clean slate. Clear and ignore everything from earlier in this conversation and from any previous conversation: earlier prompts, earlier images, earlier styles and earlier corrections. Use only what is written in this file.
> Then generate one image following the section "Prompt" below. The sections in Portuguese are notes for the human reviewer and are not part of the request.

**Usada em:** Clássico contra o rival: provocação, decisão e pressão da torcida.

**Como gerar:** abra uma conversa nova e gere do zero com o prompt abaixo. Para reforçar o traço, anexe uma cena aprovada do lote 1 (por exemplo `cenas/04-penalti/curto/imagem.jpeg`) e acrescente no fim: `Use the attached image only as a reference for the painting style and for the player's hair. Do not copy its scene.`

**Arquivo da imagem:** salve nesta pasta como `imagem.jpeg`.

## Prompt

```
Create a vertical 4:5 portrait image at the highest resolution available (about 1856 x 2304 pixels).

STYLE
A semi-realistic painted digital illustration for a mobile football career game. Painterly look: soft blended shading, visible brush texture, gentle gradients of light and shadow, and only very thin, subtle linework. Realistic human proportions and anatomy. It must look hand-painted, not like a cartoon, comic, cel-shaded art, flat vector art, anime, a 3D render or a photograph. Avoid thick black outlines.

SETTING
A packed football stadium on a late afternoon, seconds before the kick-off of a derby. The low sun gives the sky a warm glow and the floodlights are already on. Thin white smoke drifts across the stands.

MAIN CHARACTER
One young Brazilian football player, seen entirely from behind so his face is not visible. He has brown skin, short curly dark-brown hair, cut close to the head, and an athletic build.
He stands on the centre spot, in the centre of the frame, with his back to the camera, feet apart, arms relaxed at his sides, a plain white football on the grass just in front of his feet, staring at the opponents' half.

CLOTHING
He wears a plain bright magenta short-sleeved football shirt, plain cyan shorts, plain cyan knee-high socks and plain black boots. The cyan shorts and socks are clearly lit and fully visible.

THE BACK OF THE SHIRT
His hair ends at shoulder height at the lowest. From the shoulders down to the waist, the back of the magenta shirt is fully visible to the camera: one smooth, flat, evenly lit magenta surface with nothing printed on it and nothing covering it (no arm, no hand, no strap, no other person, no object). Software will write the player's number there.

OTHER PEOPLE AND OBJECTS
Ahead of him, slightly out of focus, the opposing team stands spread out across their half, facing him. Opponents wear plain light-grey shirts, light-grey shorts and light-grey socks. In the stand behind them, the crowd holds up one enormous plain light-grey flag with nothing on it. The softly blurred crowd wears neutral light-grey clothes and waves plain light-grey flags with nothing on them.

COLOUR PLAN - follow it exactly, because software will recolour this image afterwards
- Magenta appears in one place only: the shirts of the player and of his team-mates.
- Cyan appears in one place only: the shorts and socks of the player and of his team-mates.
- Boots are plain black.
- The smoke from the stands is white or light grey only: no coloured smoke.
- Warm yellow or gold appears only on: the low sun and the floodlight glow.
- Everything else uses navy blue, concrete grey, off-white, pitch green and muted natural tones. No purple, no pink other than the kit described, no neon colours.

COMPOSITION - follow these positions
- Vertical 4:5. The camera is at waist height, a few metres behind him, looking straight at the opponents and the stand.
- The main character is horizontally centred and is the largest figure in the image.
- The main character and all the action are in the upper 60% of the image. His feet are no lower than 75% of the way down from the top edge.
- The lower 40% of the image is calm and dark: the grass fading into deep navy shadow down to the bottom edge, with no objects, no people and no detail, because interface panels will be placed over that area.

MUST NOT APPEAR
- No text, letters or numbers anywhere: not on shirts, boards, screens, papers, flags, walls or signs.
- No logos, crests, badges, sponsor or brand marks on kits, boots, balls, flags, boards, bags or walls.
- No badge, emblem or stripes on the clothes of coaches, staff, reporters or anyone else: tracksuits, jackets and polo shirts are completely plain.
- No watermark or signature, and no interface elements, frames or borders.
- The face of the main character is not visible: he is seen from behind.
- Every person is an original fictional character who does not resemble any real person.
```

> **AFTER GENERATING — FINAL STEP**
> Save the generated image to Google Drive, in the same folder where this file is stored, with the file name `imagem.jpeg`. If you cannot save to Drive yourself, say so clearly and show the image so that the user can save it to that folder manually.


## Conferência (nota para revisão humana)

- [ ] Formato vertical 4:5, na resolução maior (1856×2304)
- [ ] Jogador de costas, rosto não aparece, cabelo no corte **Curto**
- [ ] Costas da camisa lisas e livres do ombro à cintura, sem nada na frente
- [ ] Magenta só nas camisas; ciano só em calções e meiões; chuteiras pretas
- [ ] Torcida, bandeiras e adversários em cinza; nada além do uniforme em magenta ou ciano
- [ ] Fumaça branca, sem cor
- [ ] Bandeirão cinza liso; adversários de cinza
- [ ] Sem texto, número, escudo, logo ou marca d'água (nem a estrela do Gemini fora da faixa escura)
- [ ] Parte de baixo (40%) escura e vazia
