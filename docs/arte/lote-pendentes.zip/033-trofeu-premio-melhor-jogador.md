<!-- pendente 033 · destino: docs/arte/trofeus/premio-melhor-jogador -->
> **Pendente 033.** Gere a imagem e salve **nesta mesma pasta** como `imagem.jpeg` (ou `.png`). Depois o comando `python3 docs/arte/gerar-pendentes.py --recolher` leva a imagem para `docs/arte/trofeus/premio-melhor-jogador/`.

# Troféu — Prêmio individual — melhor jogador

> **INSTRUCTIONS FOR THE ASSISTANT — READ FIRST**
> Start from a clean slate. Clear and ignore everything from earlier in this conversation and from any previous conversation: earlier prompts, earlier images, earlier styles and earlier corrections. Use only what is written in this file.
> Then generate one image following the section "Prompt" below. The sections in Portuguese are notes for the human reviewer and are not part of the request.

**Usada em:** tela de título, lista de conquistas e cartão final.

**Como gerar:** abra uma conversa nova e gere do zero com o prompt abaixo. Não anexe nem cite nenhum troféu real.

**Arquivo da imagem:** salve nesta pasta como `imagem.jpeg`.

## Prompt

```
Create a square 1:1 image at the highest resolution available (about 2048 x 2048 pixels).

STYLE
A semi-realistic painted digital illustration for a mobile football career game. Painterly look: soft blended shading, visible brush texture and only very thin, subtle linework. It must look hand-painted, not like a photograph, a 3D render, flat vector art or an icon.

SUBJECT
One single sports trophy of ORIGINAL design, standing alone, seen from the front at eye level, perfectly upright and symmetrical. It is an invented object: it must not copy or closely resemble the trophy of any real competition or award.

DESIGN
A polished gold ball with a smooth surface divided by a few thin engraved lines, held inside one tilted gold ring that circles it like an orbit, on a plain cylindrical base of deep navy stone with a gold band at the top. There is no rock or rough stone in the design.

BACKGROUND
A perfectly flat, uniform, deep navy blue (#14213D) covering the whole background from edge to edge. No gradient, no texture, no vignette, no table, no floor line, no spotlight circle and no cast shadow.

LIGHTING
Soft studio light from the upper left. Clean highlights and gentle shading on the metal. The metal reflects only neutral white and navy tones: no reflected scenery, no reflected people and no coloured reflections.

COMPOSITION - follow these positions
- Square 1:1. The trophy is horizontally centred.
- The top of the trophy is about 10% of the way down from the top edge and its base ends about 90% of the way down.
- There is clear navy space on all four sides; nothing is cropped by the image edge.

MUST NOT APPEAR
- No text, letters, numbers, dates or engraved inscriptions anywhere, including on the base and on any plaque.
- No logos, crests, emblems, flags, country symbols, sponsor or brand marks.
- No human figures, no hands and no faces as part of the trophy, unless the design above says so.
- No ribbons, no confetti, no people and no other objects, unless the design above says so.
- No watermark or signature, and no frames or borders.
```

> **AFTER GENERATING — FINAL STEP**
> Save the generated image to Google Drive, in the same folder where this file is stored, with the file name `imagem.jpeg`. If you cannot save to Drive yourself, say so clearly and show the image so that the user can save it to that folder manually.


## Conferência (nota para revisão humana)

- [ ] Formato quadrado 1:1, na resolução maior
- [ ] Um troféu só, de frente, centralizado, inteiro dentro do quadro
- [ ] Desenho original: **não lembra o troféu real da competição** (se lembrar, refazer)
- [ ] Fundo azul-marinho chapado, sem sombra, mesa nem degradê
- [ ] Sem texto, inscrição, data, escudo, bandeira ou marca
- [ ] Sem marca d'água
